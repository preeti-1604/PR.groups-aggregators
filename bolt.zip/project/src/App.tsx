import React, { useState, useEffect } from 'react';
import { 
  Building2, 
  Factory, 
  Zap, 
  MapPin, 
  Users, 
  CheckCircle, 
  Search, 
  Handshake, 
  FileCheck, 
  ArrowRight,
  Phone,
  Mail,
  MessageCircle,
  ChevronDown
} from 'lucide-react';

function App() {
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToSection = (id: string) => {
    document.getElementById(id)?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <div className="min-h-screen bg-white">
      {/* Navigation */}
      <nav className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        isScrolled ? 'bg-white/95 backdrop-blur-md shadow-lg' : 'bg-transparent'
      }`}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-2">
              <Building2 className={`h-8 w-8 ${isScrolled ? 'text-blue-600' : 'text-white'}`} />
              <span className={`text-xl font-bold ${isScrolled ? 'text-gray-900' : 'text-white'}`}>
                PR Groups
              </span>
            </div>
            <div className="hidden md:flex space-x-8">
              {['Services', 'Expertise', 'Projects', 'Contact'].map((item) => (
                <button
                  key={item}
                  onClick={() => scrollToSection(item.toLowerCase())}
                  className={`text-sm font-medium transition-colors hover:text-amber-500 ${
                    isScrolled ? 'text-gray-700' : 'text-white'
                  }`}
                >
                  {item}
                </button>
              ))}
            </div>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative h-screen flex items-center justify-center overflow-hidden">
        <div 
          className="absolute inset-0 bg-cover bg-center bg-no-repeat"
          style={{
            backgroundImage: 'url(https://images.pexels.com/photos/323780/pexels-photo-323780.jpeg?auto=compress&cs=tinysrgb&w=1920&h=1280&fit=crop)'
          }}
        />
        <div className="absolute inset-0 bg-gradient-to-r from-blue-900/80 to-blue-800/60" />
        
        <div className="relative z-10 text-center max-w-4xl mx-auto px-4">
          <h1 className="text-5xl md:text-7xl font-bold text-white mb-6 leading-tight">
            PR Groups
          </h1>
          <h2 className="text-2xl md:text-3xl text-amber-400 mb-8 font-medium">
            Land Aggregators in India
          </h2>
          <p className="text-xl md:text-2xl text-white/90 mb-12 max-w-3xl mx-auto leading-relaxed">
            Trusted Partners in Strategic Land Acquisition and Aggregation
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <button 
              onClick={() => scrollToSection('contact')}
              className="bg-amber-500 hover:bg-amber-600 text-white px-8 py-4 rounded-lg text-lg font-semibold transition-all duration-300 transform hover:scale-105 shadow-lg"
            >
              Get Started Today
            </button>
            <button 
              onClick={() => scrollToSection('services')}
              className="border-2 border-white text-white hover:bg-white hover:text-blue-900 px-8 py-4 rounded-lg text-lg font-semibold transition-all duration-300"
            >
              Learn More
            </button>
          </div>
        </div>
        
        <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 animate-bounce">
          <ChevronDown className="h-8 w-8 text-white" />
        </div>
      </section>

      {/* Who We Serve */}
      <section id="services" className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">
              Who We Serve
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              We specialize in land aggregation for diverse sectors, providing tailored solutions for every client
            </p>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {[
              { icon: Building2, title: 'Real Estate Developers', color: 'bg-blue-500' },
              { icon: Factory, title: 'Industrial & Infrastructure Companies', color: 'bg-green-500' },
              { icon: Users, title: 'Government Projects', color: 'bg-purple-500' },
              { icon: Zap, title: 'Renewable Energy Firms', color: 'bg-amber-500' }
            ].map((service, index) => (
              <div 
                key={index}
                className="bg-white p-8 rounded-2xl shadow-lg hover:shadow-xl transition-all duration-300 transform hover:-translate-y-2 group"
              >
                <div className={`${service.color} w-16 h-16 rounded-2xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-300`}>
                  <service.icon className="h-8 w-8 text-white" />
                </div>
                <h3 className="text-xl font-bold text-gray-900 mb-4">
                  {service.title}
                </h3>
                <div className="flex items-center text-blue-600 font-medium">
                  <CheckCircle className="h-5 w-5 mr-2" />
                  Trusted Partner
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Our Expertise */}
      <section id="expertise" className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">
              Our Expertise
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              A comprehensive 5-step process that ensures seamless land aggregation and development
            </p>
          </div>

          <div className="space-y-12">
            {[
              {
                step: '01',
                icon: Search,
                title: 'Survey & Identify Land',
                description: 'We scout strategically located land parcels with future development potential.',
                color: 'from-blue-500 to-blue-600'
              },
              {
                step: '02',
                icon: Handshake,
                title: 'Negotiate with Landowners',
                description: 'Our team manages complex negotiations with multiple individual landowners for seamless transactions.',
                color: 'from-green-500 to-green-600'
              },
              {
                step: '03',
                icon: MapPin,
                title: 'Consolidate Land',
                description: 'We assemble fragmented plots into large, viable tracts for industrial, commercial, or residential use.',
                color: 'from-purple-500 to-purple-600'
              },
              {
                step: '04',
                icon: FileCheck,
                title: 'Due Diligence',
                description: 'Clear titles, legal vetting, and zoning compliance—we ensure all groundwork is solid before handover.',
                color: 'from-amber-500 to-amber-600'
              },
              {
                step: '05',
                icon: ArrowRight,
                title: 'Facilitate Sale or Development',
                description: 'We help transfer or develop land for clients, including handover to real estate developers, energy firms, or government bodies.',
                color: 'from-red-500 to-red-600'
              }
            ].map((item, index) => (
              <div key={index} className="flex flex-col lg:flex-row items-center gap-8 group">
                <div className="flex items-center gap-6 lg:w-1/2">
                  <div className={`bg-gradient-to-r ${item.color} text-white text-2xl font-bold w-16 h-16 rounded-full flex items-center justify-center shadow-lg group-hover:scale-110 transition-transform duration-300`}>
                    {item.step}
                  </div>
                  <div className={`bg-gradient-to-r ${item.color} w-12 h-12 rounded-xl flex items-center justify-center shadow-lg`}>
                    <item.icon className="h-6 w-6 text-white" />
                  </div>
                </div>
                
                <div className="lg:w-1/2 text-center lg:text-left">
                  <h3 className="text-2xl font-bold text-gray-900 mb-4">
                    {item.title}
                  </h3>
                  <p className="text-lg text-gray-600 leading-relaxed">
                    {item.description}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Projects We Support */}
      <section 
        id="projects" 
        className="py-20 relative"
        style={{
          backgroundImage: 'url(https://images.pexels.com/photos/380768/pexels-photo-380768.jpeg?auto=compress&cs=tinysrgb&w=1920&h=1280&fit=crop)'
        }}
      >
        <div className="absolute inset-0 bg-blue-900/85" />
        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold text-white mb-6">
              Projects We Support
            </h2>
            <p className="text-xl text-white/90 max-w-3xl mx-auto">
              From industrial parks to renewable energy projects, we enable diverse development initiatives
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-8">
            {[
              {
                icon: Factory,
                title: 'Industrial Parks & SEZs',
                subtitle: 'Special Economic Zones',
                description: 'Large-scale industrial development with strategic infrastructure planning'
              },
              {
                icon: Building2,
                title: 'Residential & Commercial',
                subtitle: 'Mega-Townships',
                description: 'Comprehensive residential and commercial development projects'
              },
              {
                icon: Zap,
                title: 'Renewable Energy Projects',
                subtitle: 'Wind/Solar Farms',
                description: 'Sustainable energy infrastructure for a greener future'
              },
              {
                icon: MapPin,
                title: 'Government Infrastructure',
                subtitle: 'Development Corridors',
                description: 'Public infrastructure and strategic development initiatives'
              }
            ].map((project, index) => (
              <div key={index} className="bg-white/10 backdrop-blur-sm p-8 rounded-2xl border border-white/20 hover:bg-white/20 transition-all duration-300 group">
                <div className="flex items-center mb-6">
                  <div className="bg-amber-500 w-12 h-12 rounded-xl flex items-center justify-center mr-4 group-hover:scale-110 transition-transform duration-300">
                    <project.icon className="h-6 w-6 text-white" />
                  </div>
                  <div>
                    <h3 className="text-xl font-bold text-white">
                      {project.title}
                    </h3>
                    <p className="text-amber-400 text-sm">
                      {project.subtitle}
                    </p>
                  </div>
                </div>
                <p className="text-white/80 leading-relaxed">
                  {project.description}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-20 bg-gray-900">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold text-white mb-6">
              Contact Us
            </h2>
            <p className="text-xl text-gray-300 max-w-3xl mx-auto">
              Ready to start your land aggregation project? Get in touch with our expert team today
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8 mb-16">
            {[
              {
                icon: Mail,
                title: 'Email',
                value: 'info@pr-groups.in',
                action: 'mailto:info@pr-groups.in'
              },
              {
                icon: MessageCircle,
                title: 'WhatsApp',
                value: '+91 74115 49977',
                action: 'https://wa.me/917411549977'
              },
              {
                icon: Phone,
                title: 'Phone',
                value: '+91 74115 49977',
                action: 'tel:+917411549977'
              }
            ].map((contact, index) => (
              <a
                key={index}
                href={contact.action}
                className="bg-gray-800 p-8 rounded-2xl text-center hover:bg-gray-700 transition-all duration-300 transform hover:scale-105 group"
              >
                <div className="bg-amber-500 w-16 h-16 rounded-2xl flex items-center justify-center mx-auto mb-6 group-hover:bg-amber-400 transition-colors duration-300">
                  <contact.icon className="h-8 w-8 text-white" />
                </div>
                <h3 className="text-xl font-bold text-white mb-2">
                  {contact.title}
                </h3>
                <p className="text-gray-300">
                  {contact.value}
                </p>
              </a>
            ))}
          </div>

          <div className="text-center">
            <div className="bg-gradient-to-r from-blue-600 to-blue-700 p-8 rounded-2xl">
              <h3 className="text-2xl font-bold text-white mb-4">
                Ready to Transform Your Vision into Reality?
              </h3>
              <p className="text-blue-100 mb-6">
                Partner with India's trusted land aggregation specialists
              </p>
              <a
                href="mailto:info@pr-groups.in"
                className="bg-amber-500 hover:bg-amber-600 text-white px-8 py-4 rounded-lg text-lg font-semibold transition-all duration-300 transform hover:scale-105 shadow-lg inline-flex items-center"
              >
                Start Your Project
                <ArrowRight className="ml-2 h-5 w-5" />
              </a>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-black py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="flex items-center space-x-2 mb-4 md:mb-0">
              <Building2 className="h-8 w-8 text-amber-500" />
              <span className="text-xl font-bold text-white">PR Groups</span>
            </div>
            <p className="text-gray-400 text-center md:text-right">
              © 2025 PR Groups. Trusted Partners in Land Aggregation.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default App;